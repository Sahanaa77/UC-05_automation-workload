# WorkloadLens UC-05 — Traceable Acceptance Matrix (A01–A12)

> **Use Case ID:** UC-05 | **Product:** WorkloadLens (Automation Workload Preview SaaS)  
> **Team:** Code Sapiens  
> **Target Cloud:** `https://workloadlens-api-dev.ashyglacier-4fc4aa73.centralindia.azurecontainerapps.io`  
> **Verification Status:** A01–A11 Automated & Live Verified (11/11 PASS); A12 Ready for Peer Verification

---

## 1. Acceptance Matrix Summary

| Check ID | Requirement Summary | Verification Command | Expected Behavior | Actual Observed Outcome | Evidence Path | Status |
|:---:|---|---|---|---|---|:---:|
| **A01** | Deployment & Infrastructure Verification | `curl -s https://${FQDN}/health`<br/>`terraform -chdir=infra validate`<br/>`terraform -chdir=infra plan -detailed-exitcode` | Public `/health` returns 200 without auth; Terraform manages exactly 2 resources (`azurerm_container_app.api`, `azurerm_storage_container.data`); zero drift on repeat plan. | `{"status":"ok"}` returned. Terraform configuration valid. Repeat plan exits with code 0 (no changes). | [`evidence/terraform-no-changes.txt`](../../evidence/terraform-no-changes.txt)<br/>[`evidence/ACCEPTANCE_EVIDENCE.md`](../../evidence/ACCEPTANCE_EVIDENCE.md) | **PASS** |
| **A02** | Valid Fixture Validation | `POST /runs` with 2 valid rows (J01, J02)<br/>`operation: "validate"` | HTTP 201 Created; `valid_rows: 2`, `invalid_rows: 0`, `issues: []`. | HTTP 201 Created; `run_id` returned; `valid_rows: 2`, `invalid_rows: 0`, `issues: []`. | [`docs/screenshots/run-tools-validation-success.png`](../screenshots/run-tools-validation-success.png)<br/>[`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L48) | **PASS** |
| **A03** | Invalid Fixture Validation (Rules R1–R4) | `POST /runs` with 6 rows (2 valid + 4 invalid)<br/>`operation: "validate"` | HTTP 201 Created; `valid_rows: 2`, `invalid_rows: 4`; distinct issues reporting R1, R2, R3, R4 with 1-based row index. | HTTP 201 Created; `valid_rows: 2`, `invalid_rows: 4`; all 4 rules confirmed (`R1` duplicate, `R2` DELETE tool, `R3` count 0, `R4` PROD env). | [`docs/screenshots/run-tools-validation-errors.png`](../screenshots/run-tools-validation-errors.png)<br/>[`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L71) | **PASS** |
| **A04** | Pro Plan Processing & Persistence | `POST /runs` with valid 2 rows<br/>`operation: "process"` | HTTP 201 Created; returns J01=200ms, J02=100ms, total=300ms; persisted across container restarts. | HTTP 201 Created; summary: `{total_records: 30, total_estimated_ms: 300}`; retrievable via `GET /runs/{id}/result`. | [`docs/screenshots/run-tools-processing-success.png`](../screenshots/run-tools-processing-success.png)<br/>[`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L112) | **PASS** |
| **A05** | Invalid Request Bounds & Zero Quota Debit | `POST /runs` (`operation: "process"` with invalid rows, wrong body shape, or 11 rows) | HTTP 400 Bad Request; zero runs created; zero quota debited. | HTTP 400 Bad Request (`Process operation rejects invalid input rows`); daily quota count remains unchanged. | [`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L143)<br/>[`backend/tests/test_edge.py`](../../backend/tests/test_edge.py#L65) | **PASS** |
| **A06** | Authentication, Roles, & Permissions | Protected endpoints without auth; Viewer submit; Basic plan process | Unauthenticated returns 401; Viewer submitting returns 403; Basic plan submitting process returns 403; quota unchanged. | HTTP 401 on missing token; HTTP 403 for Viewer submissions; HTTP 403 for Basic process submissions. | [`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L173)<br/>[`backend/tests/test_auth_and_harness.py`](../../backend/tests/test_auth_and_harness.py#L32) | **PASS** |
| **A07** | Strict Cross-Tenant Isolation | Tenant B attempts to read Tenant A run; `X-Tenant-Override` header sent | Tenant B cannot list or get Tenant A run (returns 404); tenant override header rejected with 400. | Tenant A run omitted from Tenant B history; `GET /runs/{id}/result` returns 404; `X-Tenant-Override` rejected with 400. | [`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L210)<br/>[`evidence/ACCEPTANCE_EVIDENCE.md`](../../evidence/ACCEPTANCE_EVIDENCE.md#L21) | **PASS** |
| **A08** | Daily Quota & Concurrency Race Condition | Basic plan submits 4 runs; 2 threads submit simultaneously for final slot | Basic accepts exactly 3 runs/day, rejects 4th with 429; concurrent race condition accepts exactly 1 run (201) and rejects other with 429. | Runs 1–3 return 201; Run 4 returns 429; under multithreaded competition, exactly one thread achieves 201, other receives 429. | [`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L240)<br/>[`backend/tests/test_runs_flow.py`](../../backend/tests/test_runs_flow.py#L106) | **PASS** |
| **A09** | Idempotency Replay & Conflict Detection | Replay identical key & payload; replay same key with altered payload | Matching key & payload returns existing run with 200 OK (0 quota debit, even if quota exhausted); altered payload returns 409 Conflict. | Identical replay returns original run ID with HTTP 200 OK and 0 additional debit; altered payload returns HTTP 409 Conflict. | [`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L293)<br/>[`backend/tests/test_runs_flow.py`](../../backend/tests/test_runs_flow.py#L82) | **PASS** |
| **A10** | Suspended Subscription Restrictions | Suspended tenant submits run; suspended tenant reads historical runs | New submissions return 403 Forbidden with 0 quota debit; historical reads (`GET /runs`) remain accessible (200 OK). | `POST /runs` returns 403 Forbidden; `GET /runs` returns 200 OK with previously accepted runs. | [`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L348)<br/>[`backend/tests/test_read_routes.py`](../../backend/tests/test_read_routes.py#L65) | **PASS** |
| **A11** | Processing Failure Hook & Quota Lifecycle | `POST /runs` with `X-Test-Force-Failure: 1` header | Run accepted into terminal status `"Failed"`, failure error recorded, exactly 1 quota slot consumed; replay returns recorded `"Failed"` status with 200 OK without re-execution. | Run status `"Failed"`, error recorded; quota debited by 1; replay returns 200 OK with identical run ID and `"Failed"` status. | [`backend/tests/test_uc05_acceptance.py`](../../backend/tests/test_uc05_acceptance.py#L385)<br/>[`backend/tests/test_runs_flow.py`](../../backend/tests/test_runs_flow.py#L136) | **PASS** |
| **A12** | Independent Verification via Operational Guide | Independent replay following `skills/automation-preview/SKILL.md` Section 5 | Reproducible fresh session verifies Procedures A, B, and C with genuine outputs and no failures. | Intended Peer Verifier: Poojhaa K ([@Poojhaakarthikeyan](https://github.com/Poojhaakarthikeyan)). Documented reproducible operational guide and runbook in SKILL.md; prepared for peer teammate execution. | [`skills/automation-preview/SKILL.md`](../../skills/automation-preview/SKILL.md)<br/>[`evidence/ACCEPTANCE_EVIDENCE.md`](../../evidence/ACCEPTANCE_EVIDENCE.md#L26) | **READY FOR PEER VERIFICATION** |

---

### A12 Peer Verification Protocol

* **Designated Peer Verifier:** Poojhaa K (Team Lead & Technical Coordination, [@Poojhaakarthikeyan](https://github.com/Poojhaakarthikeyan)).
* **Environment Requirement:** A fresh, independent shell session or clean workstation clone.
* **Credential Policy:** No personal account credentials, passwords, or private tokens are required or permitted to be logged. Replay operations utilize standard test fixture identity tokens (`token-tenant-a-operator`) as specified in the operational guide.
* **Procedure Scope:**
  1. **Procedure A (Valid Fixture):** Verify `POST /runs` (`operation: validate`, 2 rows) returns `HTTP 201 Created` with `valid_rows: 2`, `invalid_rows: 0`.
  2. **Procedure B (Invalid Fixture):** Verify `POST /runs` (`operation: validate`, 6 rows) returns `HTTP 201 Created` with `valid_rows: 2`, `invalid_rows: 4`, confirming R1–R4 rule violations. Verify `operation: process` rejects with `HTTP 400 Bad Request`.
  3. **Procedure C (Forced Processing Failure):** Verify `POST /runs` with `X-Test-Force-Failure: 1` sets terminal `status: "Failed"`, consumes 1 quota slot, and idempotent replay returns the persisted Failed run without re-execution.
* **Outcome Recording:** Upon completion, Poojhaa will record genuine command outputs, execution timestamps, and final PASS determination. Until that independent replay is executed, A12 remains strictly marked **READY FOR PEER VERIFICATION**.

---

## 2. Screenshot Verification Index

All screenshots were authentically captured at a consistent desktop resolution of **1440 × 900** using headless Microsoft Edge against the redesigned Contemporary Heritage application:

1. **Clean Initial Run Tools:** [`docs/screenshots/run-tools.png`](../screenshots/run-tools.png)
2. **Successful Validation Result:** [`docs/screenshots/run-tools-validation-success.png`](../screenshots/run-tools-validation-success.png)
3. **Invalid Fixture (R1–R4 Issues):** [`docs/screenshots/run-tools-validation-errors.png`](../screenshots/run-tools-validation-errors.png)
4. **Pro Plan Processing Output:** [`docs/screenshots/run-tools-processing-success.png`](../screenshots/run-tools-processing-success.png)
5. **Populated History Table:** [`docs/screenshots/history-populated.png`](../screenshots/history-populated.png)
6. **Detailed Result Inspection:** [`docs/screenshots/history-run-details.png`](../screenshots/history-run-details.png)
